/*******************************************************************************
* File Name: XPT2046.c
*
* Description:
*  This is a driver for the Touch Screen Controller  XPT2046 
*
*  Setup by SPI
*
********************************************************************************
* Copyright (c) 2018 Andres F. Navas
*******************************************************************************/

#include <project.h>
#include <stdlib.h>
#include "XPT2046.h"


/****************************************************************************************************
*                                    Reading the position of the pen   
*    send 3 bytes and collect the 12-bit ADC value (see datasheet XTP2046)
****************************************************************************************************/
uint16 ReadPos(uint16 coord)
{
    uint16 Hi,Lo;    
    SPI_ClearTxBuffer();
    SPI_WriteTxData(coord);             // 0x90 is the X coordinate; 0xD0 is the Y coordinate
    SPI_ReadRxData();                   
    SPI_WriteTxData(coord);
    //CyDelayUs(1);
    Hi =((uint16)SPI_ReadRxData())<<4;  // higher 4 bits
    SPI_WriteTxData(0x03);
    Lo =(uint16)SPI_ReadRxData();    // lower Byte
    CyDelayUs(2);
    //SPI_ClearRxBuffer();
    return (Hi+Lo);                       // 12 bit ADC
}//...................................


/**********************************************************************************
*           OBTAINING CALIBRATION COORDINATES
*    read both coordinates 2 times, if the error is less than the specified value (25) - 
*    we update the coordinate values ​​taking into account the calibration.
**********************************************************************************/
void ReadXY(uint16 X,  uint16 Y)  // 0xD0   0x90
{
    uint16 x0, y0, x1, y1;	
    x0 = ReadPos(0x91); y0 = ReadPos(0xD1);                         // read coordinates
    x1 = ReadPos(0x90); y1 = ReadPos(0xD0);	                        // again...
    //if((abs(x0-x1) < 25) && (abs(y0-y1) < 25))                      // if the error is less than 20
    // { *X = x1;  *Y = y1;      	                                    // update the current coordinate values
       X  = (x0+x1)/2;                                          // and calibrate the values ​​of X
       Y  = (y0+y1)/2;                                          // and Y
     //}
}//................................
