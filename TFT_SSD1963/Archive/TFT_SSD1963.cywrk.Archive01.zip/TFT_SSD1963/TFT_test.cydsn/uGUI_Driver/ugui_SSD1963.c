/*******************************************************************************
* File Name: ugui_SSD1963.c
*
* Description:
*  This is a driver for the uGui graphical library developed by 
*  Achim Döbler.
*  It is for SSD1963 graphic controller found in a lot of low cost graphics 
*  chinese displays an to be used with PSoC microcontrollers from Cypress.
*  Will test it with other PSoC micros as soon as i can.
*
* Note:
*  For more information about uGui...
*  Website: http://www.embeddedlightning.com/ugui/
*  Git: https://github.com/achimdoebler/UGUI
*  Forum: http://www.embeddedlightning.com/forum/
*  PDF Reference manual (excellent): http://www.embeddedlightning.com/download/reference-guide/?wpdmdl=205
*
*  Thanks to Achim Döbler for such a god job.
*
* Log version:
*  1.0 - June, 2018.       First version.
*
********************************************************************************
* Copyright (c) 2018 Andres F. Navas
* This driver follows the same license than the uGui library.
*******************************************************************************/

//#include "ugui_config.h"
#include <project.h>
#include "ugui.h"
#include "ugui_SSD1963.h"

inline void Display_WriteCommand(uint8_t command)
{
    GraphicLCDIntf_Write8(0, command);
}

inline void Display_WriteData(uint8_t data)
{
    GraphicLCDIntf_Write8(1, data);
}

inline void Display_WriteMultiData(uint8_t *data, uint16 size)
{
    GraphicLCDIntf_WriteM8(1, data, size);
}

inline void Display_Reset()
{
    Display_WriteCommand(0x01);     //Software reset
    CyDelay(10);
}

void Display_Init()
{
    int i;
    
    CyDelay(100);
	
    for(i = 0; i < 5; i++)              // Hardware reset
    {
        rst_Write(0);
		CyDelay(10);
        rst_Write(1);
        CyDelay(10);
	}
    
    Display_Reset();                    //Software reset
    CyDelay(5);
    Display_Reset();                    //Software reset
    CyDelay(5);
    Display_Reset();                    //Software reset
    CyDelay(5);

    Display_WriteCommand(0xe2);         //set multiplier and divider of PLL
    Display_WriteData(0x23);            //PLL 120MHz
    Display_WriteData(0x02);
    Display_WriteData(0x04);
    
    Display_WriteCommand(0xe0);
    Display_WriteData(0x01);            //Enable PLL
    CyDelay(10);
    
    Display_WriteCommand(0xe0);
    Display_WriteData(0x03);            //Lock PLL
    CyDelay(10);
    Display_Reset();                    //Software reset
       
    Display_WriteCommand(0xe6);   		//SET PCLK freq=33.26MHz
    Display_WriteData(0x04);            
    Display_WriteData(0x6f);            
    Display_WriteData(0x46);
    
    Display_WriteCommand(0xb0);		    //SET LCD MODE  SET TFT 18Bits MODE
    Display_WriteData(0x27);			//SET TFT MODE & hsync+Vsync+DEN MODE
    Display_WriteData(0x00);			//SET TFT MODE & hsync+Vsync+DEN MODE
    Display_WriteData(0x03);			//SET horizontal size= 800-1 HightByte
    Display_WriteData(0x1f);		    //SET horizontal size= 800-1 LowByte
    Display_WriteData(0x01);			//SET vertical size= 480-1 HightByte
    Display_WriteData(0xdf);			//SET vertical size= 480-1 LowByte
    Display_WriteData(0x00);			//SET even/odd line RGB seq.=RGB 

    Display_WriteCommand(0xb4);         //SET HBP,
    Display_WriteData(0x03);            //SET HSYNC Total= 928 HightByte
    Display_WriteData(0xa0);            //SET HSYNC Total= 928 LowByte
    Display_WriteData(0x00);            //SET HPS 0 HightByte
    Display_WriteData(0x2e);            //SET HPS 46 LowByte
    Display_WriteData(0x30);            //SET HPW 48 
    Display_WriteData(0x00);            //SET Hsync pulse start position  (0 HighByte)
    Display_WriteData(0x0f);            //15 LowByte
    Display_WriteData(0x00);            //SET Hsync pulse subpixel start position
    
    Display_WriteCommand(0xb6);         //SET VBP,
    Display_WriteData(0x02);            //SET Vsync total= 525 HighByte
    Display_WriteData(0x0d);            //525 LowByte
    Display_WriteData(0x00);            //SET VBP 0 HighByte
    Display_WriteData(0x10);            //VBP 16 LowByte
    Display_WriteData(0x10);            //SET Vsync pulse 16
    Display_WriteData(0x00);            //SET Vsync pulse start position (0 HighByte)
    Display_WriteData(0x08);            //8 LowByte
    
    Display_WriteCommand(0x36);
    Display_WriteData(0x00);	        //SET rotation
    
    Display_WriteCommand(0xf0);
    Display_WriteData(0x00);	        //SET pixel data I/F format=8bit
    
    CyDelay(5);
    
    Display_WriteCommand(0x29);		//SET display on
    CyDelay(10);
   
    // Initialize global structure and set PSET to this.PSET. 
    UG_Init(&gui1963, Display_PSet, DISPLAY_WIDTH, DISPLAY_HEIGHT); 
    
    // Register acceleratos.
    UG_DriverRegister(DRIVER_FILL_FRAME, (void*)HW_FillFrame);
    UG_DriverRegister(DRIVER_DRAW_LINE, (void*)HW_DrawLine);
    
}

void Display_WindowSet(unsigned int s_x,unsigned int e_x,unsigned int s_y,unsigned int e_y)
{
    uint8_t data[4];
    
    data[0] = ((s_x)>>8);                   //SET start column address
    data[1] = (s_x);
    data[2] = ((e_x)>>8);			        //SET end column address
    data[3] = (e_x);
	Display_WriteCommand(0x2a);		        //SET column address
    Display_WriteMultiData(data, 4);

	
    data[0] = ((s_y)>>8);                   //SET start row address
    data[1] = (s_y);
    data[2] = ((e_y)>>8);			        //SET end row address
    data[3] = (e_y);
	Display_WriteCommand(0x2b);		        //SET row address
    Display_WriteMultiData(data, 4);
}

void Display_PSet(UG_S16 x, UG_S16 y, UG_COLOR c)
{    
    uint8_t data[3];
    
    data[0] = (c >> 16);
    data[1] = (c >> 8);
    data[2] = (c);
    
    if((x < 0) ||(x >= DISPLAY_WIDTH) || (y < 0) || (y >= DISPLAY_HEIGHT)) return;
 
    Display_WindowSet(x, x + 1, y, y + 1);    
    Display_WriteCommand(0x2c);
    Display_WriteMultiData(data, 3);

}

void Display_setFrameAdr( int adr ) 
{
	Display_WriteCommand(0x37);
	Display_WriteData((uint8_t)(adr>>8));
	Display_WriteData((uint8_t)(adr));
}

UG_RESULT HW_FillFrame(UG_S16 x1, UG_S16 y1, UG_S16 x2, UG_S16 y2, UG_COLOR c)
{
    uint16 loopx, loopy;
    uint8_t data[3];
    
    data[0] = (c >> 16);
    data[1] = (c >> 8);
    data[2] = (c);
    
    if((x1 < 0) ||(x1 >= DISPLAY_WIDTH) || (y1 < 0) || (y1 >= DISPLAY_HEIGHT)) return UG_RESULT_FAIL;
    if((x2 < 0) ||(x2 >= DISPLAY_WIDTH) || (y2 < 0) || (y2 >= DISPLAY_HEIGHT)) return UG_RESULT_FAIL;

    Display_WindowSet(x1,x2,y1,y2);

    Display_WriteCommand(0x2c);            
    for (loopx = x1; loopx < x2 + 1; loopx++)
    {
        for (loopy = y1; loopy < y2 + 1; loopy++)
        {
            Display_WriteMultiData(data, 3);
        }
    } 
    
    return UG_RESULT_OK;
}

UG_RESULT HW_DrawLine( UG_S16 x1 , UG_S16 y1 , UG_S16 x2 , UG_S16 y2 , UG_COLOR c )
{
    if((x1 < 0) ||(x1 >= DISPLAY_WIDTH) || (y1 < 0) || (y1 >= DISPLAY_HEIGHT)) return UG_RESULT_FAIL;
    if((x2 < 0) ||(x2 >= DISPLAY_WIDTH) || (y2 < 0) || (y2 >= DISPLAY_HEIGHT)) return UG_RESULT_FAIL;
    
    // If it is a vertical or a horizontal line, draw it.
    // If not, then use original drawline routine.
    if ((x1 == x2) || (y1 == y2)) 
    {
        HW_FillFrame(x1, y1, x2, y2, c);
        return UG_RESULT_OK;
    }
    
    return UG_RESULT_FAIL;
}

UG_RESULT HW_DrawImage(UG_S16 x1, UG_S16 y1, UG_S16 x2, UG_S16 y2, uint8_t *image, uint16_t pSize)
{
        
    if((x1 < 0) ||(x1 >= DISPLAY_WIDTH) || (y1 < 0) || (y1 >= DISPLAY_HEIGHT)) return UG_RESULT_FAIL;
    if((x2 < 0) ||(x2 >= DISPLAY_WIDTH) || (y2 < 0) || (y2 >= DISPLAY_HEIGHT)) return UG_RESULT_FAIL;

    Display_WindowSet(x1,x2,y1,y2);

    Display_WriteCommand(0x2c);            
    Display_WriteMultiData(image, pSize*3);
    
    return UG_RESULT_OK;
}

/* [] END OF FILE */
