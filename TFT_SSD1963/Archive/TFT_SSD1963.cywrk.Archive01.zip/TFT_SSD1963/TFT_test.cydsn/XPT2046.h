/*******************************************************************************
* File Name: XPT2046.h
*
* Description:
*  This is a driver for the Touch Screen Controller  XPT2046 
*
*  Setup by SPI
*
********************************************************************************
* Copyright (c) 2018 Andres F. Navas
*******************************************************************************/

#include <project.h>

uint16 PosX;
uint16 PosY;

uint16 ReadPos(uint16 coord);           // Reading pen coordinate 0x90 - X coordinate; 0xD0 is the Y coordinate
void ReadXY(uint16 X,  uint16 Y);     // OBTAINING CALIBRATION COORDINATES