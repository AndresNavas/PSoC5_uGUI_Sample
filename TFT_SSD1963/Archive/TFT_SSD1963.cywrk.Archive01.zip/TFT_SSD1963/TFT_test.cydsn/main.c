/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "project.h"
#include "ugui.h"
#include "ugui_SSD1963.h"
#include "Images.h"
#include "XPT2046.h"


#define MAX_OBJECTS 10
#define BuffOUT     40

char bufferOut[BuffOUT];

void window_1_callback(UG_MESSAGE *msg);

int main(void)
{
    char cont;    
    UG_COLOR color[3];
    
    UG_WINDOW window_1;
    UG_BUTTON button_1;
    UG_BUTTON button_2;
    UG_BUTTON button_3;
    UG_TEXTBOX textbox_1;
    UG_OBJECT obj_buff_wnd_1[MAX_OBJECTS];

    
    CyGlobalIntEnable; /* Enable global interrupts. */
    color[0] = C_RED;
    color[1] = C_GREEN;
    color[2] = C_BLUE;
    
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    //Clock_LCD_SetDividerRegister(0,1);   // Full clock speed
    GraphicLCDIntf_Start();
    Display_Init();
    SPI_Start();                            // Start SPI (Touch Controller)
    //SPI_WriteTxData(0x90);
    ReadPos(0x93);

    CyDelay(100);
    
    /* Clear screen. */
    UG_FillScreen(C_BLACK);
    UG_DrawFrame(0, 0, 799, 479, C_LIGHT_GRAY);     // Draw a Frame
    CyDelay(10);
    bl_e_Write(1);      // Turn on BackLight    
    
    //Some Texts
    UG_FontSelect(&FONT_12X16);
    UG_SetBackcolor(C_BLACK);
    UG_SetForecolor(C_YELLOW);
    UG_PutString(5, 5 , "TFT 5\"");
    UG_FontSelect(&FONT_12X16);
    UG_SetBackcolor(C_BLACK);
    UG_SetForecolor(C_YELLOW);
    UG_PutString(5, 23, "PSoC 5LP");

    
    // Create the window
    UG_WindowCreate(&window_1, obj_buff_wnd_1, MAX_OBJECTS, window_1_callback);
    // Window Title
    UG_WindowSetTitleText(&window_1, "Test Window");
    UG_WindowSetTitleTextFont(&window_1, &FONT_12X16);
    UG_WindowSetXStart(&window_1, 275);
    UG_WindowSetYStart(&window_1, 200);
    UG_WindowSetXEnd(&window_1, 725);
    UG_WindowSetYEnd(&window_1, 450);
    
    // Create Buttons
    UG_ButtonCreate(&window_1, &button_1, BTN_ID_0, 10, 10, 110, 60);
    UG_ButtonCreate(&window_1, &button_2, BTN_ID_1, 10, 80, 110, 130);
    UG_ButtonSetStyle(&window_1,BTN_ID_1, BTN_STYLE_3D | BTN_STYLE_TOGGLE_COLORS | BTN_STYLE_USE_ALTERNATE_COLORS);
    UG_ButtonCreate(&window_1, &button_3, BTN_ID_2, 10, 150, 110, 200);
    //Label Buttons
    UG_ButtonSetFont(&window_1,BTN_ID_0,&FONT_8X14);
    UG_ButtonSetForeColor(&window_1,BTN_ID_0, C_BLUE);
    UG_ButtonSetText(&window_1,BTN_ID_0,"Button \nA");
    UG_ButtonSetFont(&window_1,BTN_ID_1,&FONT_8X14);
    UG_ButtonSetForeColor(&window_1,BTN_ID_1, C_RED);
    UG_ButtonSetText(&window_1,BTN_ID_1,"Button \nB");
    UG_ButtonSetFont(&window_1,BTN_ID_2,&FONT_8X14);
    UG_ButtonSetForeColor(&window_1,BTN_ID_2, C_BLACK);
    UG_ButtonSetText(&window_1,BTN_ID_2,"Button \nC");
    
    // Create Textbox
    UG_TextboxCreate(&window_1, &textbox_1, TXB_ID_0, 120, 10, 440, 200);
    UG_TextboxSetFont(&window_1, TXB_ID_0, &FONT_16X26);
    UG_TextboxSetText(&window_1, TXB_ID_0, "This is a \n test sample window!");
    UG_TextboxSetForeColor(&window_1, TXB_ID_0, C_BLACK);
    UG_TextboxSetAlignment(&window_1, TXB_ID_0, ALIGN_CENTER);
    
    UG_WindowShow(&window_1);
    UG_Update();
    
    HW_DrawImage(20, 200, 215, 302, acCapture, (195*102));
    
    cont = 0;
    for(;;)
    {
    /* Some graphic primitives for testing. */      
        
        UG_DrawFrame(3, 49, 124, 156, C_RED);
        UG_FillFrame(4, 50, 123, 155, color[0]);
        UG_DrawFrame(126, 49, 247, 156, C_GREEN);
        UG_FillFrame(127, 50, 246, 155, color[1]);
        UG_DrawFrame(249, 49, 370, 156, C_BLUE);
        UG_FillFrame(250, 50, 369, 155, color[2]);
        
        UG_FontSelect(&FONT_22X36);
        UG_SetBackcolor(C_BLACK);
        UG_SetForecolor(C_WHITE);
        UG_PutString(400, 90, "Andres Navas");
        UG_Update();
        
        CyDelay(500);
        
        color[0] = color[0] >> 8;
        color[1] = color[1] >> 8;
        color[2] = color[2] >> 8;
        if(color[0] == 0x000000) color[0] = C_RED;
        if(color[1] == 0x000000) color[1] = C_RED;
        if(color[2] == 0x000000) color[2] = C_RED;
        
        cont++;
        if(cont >= 2) 
        {
            cont = 0;
            UG_ButtonSetAlternateBackColor(&window_1, BTN_ID_1, C_BLUE);
            UG_ButtonSetText(&window_1,BTN_ID_1,"Button \nb");
            //UG_WindowShow(&window_1);
        }
        else
            UG_ButtonSetText(&window_1,BTN_ID_1,"Button \nB");
            
        //ReadXY(PosX, PosY);        //  Read TouchScreen Coordinates
        ReadPos(0x93);
        ReadPos(0x93);
        PosX = ReadPos(0x93);
       // SPI_ClearRxBuffer();
//        ReadPos(0xd3);
//        ReadPos(0xd3);
//        PosY = ReadPos(0xd3);
       // SPI_ClearRxBuffer();
        UG_FontSelect(&FONT_12X16);
        UG_SetBackcolor(C_BLACK);
        UG_SetForecolor(C_RED);
        sprintf(bufferOut,"X = %d     ", PosX);
        UG_PutString(200, 5 , bufferOut);
        sprintf(bufferOut,"Y = %d     ", PosY);
        UG_PutString(200, 23, bufferOut);       
    }
}

void window_1_callback(UG_MESSAGE *msg)
{
    if(msg->type == MSG_TYPE_OBJECT)
    {
        CyDelay(5);
    }
    
}


/* [] END OF FILE */
